﻿import { spawn } from "node:child_process";

const child = spawn(process.execPath, ["server.js"], {
  cwd: process.cwd(),
  stdio: ["pipe", "pipe", "inherit"],
});

let buf = "";
function send(obj) {
  child.stdin.write(JSON.stringify(obj) + "\n");
}
function once(method, id, params) {
  return new Promise((resolve) => {
    const onLine = (line) => {
      let m; try { m = JSON.parse(line); } catch { return; }
      if (m.id === id) { child.stdout.off("data", onData); resolve(m); }
    };
    const onData = (d) => { buf += d.toString(); let i; while ((i = buf.indexOf("\n")) >= 0) { onLine(buf.slice(0, i)); buf = buf.slice(i + 1); } };
    child.stdout.on("data", onData);
    send({ jsonrpc: "2.0", id, method, params });
  });
}

const out = (label, v) => console.log("\n===== " + label + " =====\n" + JSON.stringify(v, null, 2).slice(0, 1500));

(async () => {
  const init = await once("initialize", 1, {
    protocolVersion: "2024-11-05",
    capabilities: {},
    clientInfo: { name: "self-test", version: "0.0.0" },
  });
  out("initialize", init);
  send({ jsonrpc: "2.0", method: "notifications/initialized" });

  const tl = await once("tools/list", 2, {});
  console.log("\n===== tools/list =====\n" + tl.result.tools.map((t) => t.name).join(", "));

  const ss = await once("tools/call", 3, { name: "system_stats", arguments: {} });
  out("system_stats", JSON.parse(ss.result.content[0].text));

  const lm = await once("tools/call", 4, { name: "list_models", arguments: {} });
  out("list_models", JSON.parse(lm.result.content[0].text));

  const ln = await once("tools/call", 5, { name: "list_nodes", arguments: { filter: "CheckpointLoader" } });
  out("list_nodes(CheckpointLoader)", JSON.parse(ln.result.content[0].text));

  child.kill();
  process.exit(0);
})();
