﻿import { spawn } from "node:child_process";

const child = spawn(process.execPath, ["server.js"], { cwd: process.cwd(), stdio: ["pipe", "pipe", "inherit"] });
let buf = "";
function send(o){ child.stdin.write(JSON.stringify(o)+"\n"); }
function call(id, name, args){ return new Promise((res)=>{ const onLine=(line)=>{let m;try{m=JSON.parse(line)}catch{return} if(m.id===id){child.stdout.off("data",onData);res(m)}}; const onData=(d)=>{buf+=d.toString();let i;while((i=buf.indexOf("\n"))>=0){onLine(buf.slice(0,i));buf=buf.slice(i+1)}}; child.stdout.on("data",onData); send({jsonrpc:"2.0",id,method:"tools/call",params:{name,arguments:args}}); }); }

// 最小文生图工作流 (API 格式) — SDXL base + 默认 VAE
const prompt = {
  "4": { class_type: "CheckpointLoaderSimple", inputs: { ckpt_name: "sd_xl_base_1.0.safetensors" } },
  "5": { class_type: "EmptyLatentImage", inputs: { width: 512, height: 512, batch_size: 1 } },
  "6": { class_type: "CLIPTextEncode", inputs: { text: "a cute corgi astronaut on the moon, highly detailed", clip: ["4", 1] } },
  "7": { class_type: "CLIPTextEncode", inputs: { text: "blurry, low quality", clip: ["4", 1] } },
  "3": { class_type: "KSampler", inputs: { seed: 42, steps: 18, cfg: 7, sampler_name: "euler", scheduler: "normal", denoise: 1, model: ["4", 0], positive: ["6", 0], negative: ["7", 0], latent_image: ["5", 0] } },
  "8": { class_type: "VAEDecode", inputs: { samples: ["3", 0], vae: ["4", 2] } },
  "9": { class_type: "SaveImage", inputs: { filename_prefix: "mcp_test", images: ["8", 0] } },
};

(async () => {
  await call(1, "initialize", {}); // warm up handshake (returns regardless)
  send({ jsonrpc: "2.0", method: "notifications/initialized" });
  const r = await call(2, "run_workflow", { prompt, timeout: 180 });
  const summary = JSON.parse(r.result.content[0].text);
  console.log("\n===== run_workflow 结果 =====");
  console.log("state:", summary.state);
  console.log("prompt_id:", summary.prompt_id);
  console.log("outputs:", JSON.stringify(summary.outputs, null, 2));
  if (r.result.content.length > 1) console.log("(含内联图片预览)");
  child.kill();
  process.exit(summary.state === "success" ? 0 : 2);
})();
