﻿import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";
import { randomUUID } from "node:crypto";
import { writeFile, mkdir, readFile } from "node:fs/promises";
import { join } from "node:path";

const BASE = (process.env.COMFYUI_URL || "http://127.0.0.1:8188").replace(/\/+$/, "");
const OUTDIR = process.env.COMFYUI_OUTDIR || join(process.env.USERPROFILE || "C:\\Users\\FG", ".codex", "mcp_outputs");
const CLIENT_ID = randomUUID();

const MODEL_FOLDERS = [
  "checkpoints", "diffusion_models", "unet", "vae", "loras", "clip", "text_encoders",
  "clip_vision", "embeddings", "controlnet", "upscale_models", "style_models",
  "gligen", "hypernetworks", "ipadapter", "diffusers", "configs"
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function api(path, opts = {}, timeoutMs = 30000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(BASE + path, { ...opts, signal: ctrl.signal });
    const txt = await r.text();
    let body;
    try { body = JSON.parse(txt); } catch { body = txt; }
    if (!r.ok) {
      throw new Error("HTTP " + r.status + " " + path + ": " + (typeof body === "string" ? body : JSON.stringify(body).slice(0, 800)));
    }
    return body;
  } finally { clearTimeout(t); }
}

let _oiCache = null;
async function objectInfoAll() {
  if (!_oiCache) _oiCache = await api("/object_info");
  return _oiCache;
}

async function downloadFile({ filename, subfolder = "", type = "output", save_as }) {
  const params = new URLSearchParams({ filename, subfolder, type });
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 180000);
  try {
    const r = await fetch(BASE + "/view?" + params.toString(), { signal: ctrl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const buf = Buffer.from(await r.arrayBuffer());
    await mkdir(OUTDIR, { recursive: true });
    const out = join(OUTDIR, save_as || filename);
    await writeFile(out, buf);
    return { path: out, bytes: buf.length };
  } finally { clearTimeout(t); }
}

function collectOutputs(historyOutputs) {
  const files = [];
  for (const [nid, out] of Object.entries(historyOutputs || {})) {
    for (const key of ["images", "gifs", "videos", "audio"]) {
      for (const fi of out[key] || []) {
        files.push({ node: nid, kind: key, filename: fi.filename, subfolder: fi.subfolder || "", type: fi.type || "output" });
      }
    }
  }
  return files;
}

async function imageContent(localPath) {
  const ext = (localPath.split(".").pop() || "").toLowerCase();
  if (!["png", "jpg", "jpeg", "webp", "gif"].includes(ext)) return null;
  const mime = ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : ext === "gif" ? "image/gif" : "image/jpeg";
  const b = await readFile(localPath);
  return { type: "image", data: b.toString("base64"), mimeType: mime };
}

const tools = [
  {
    name: "system_stats",
    description: "Get ComfyUI system stats: version, RAM, GPU devices and VRAM usage. No args. Useful as a connectivity/health check.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "list_nodes",
    description: "List all available ComfyUI node class_type names (the building blocks of a workflow graph). Optional `filter` substring (case-insensitive) narrows the list, e.g. filter='Checkpoint', 'Save', 'Wan', 'EmptyLatent'. Step 1 of building a workflow: find the node class_type names you need.",
    inputSchema: { type: "object", properties: { filter: { type: "string" } } },
  },
  {
    name: "get_node_info",
    description: "Get full definitions of one or more node class_types: required/optional inputs (each with type or allowed values + tooltip), and output slots (output / output_name). Use after list_nodes to learn exactly how to fill each node and how to wire outputs into other nodes' inputs. A wire is expressed as [source_node_id, output_index].",
    inputSchema: { type: "object", properties: { nodes: { type: "array", items: { type: "string" } } }, required: ["nodes"] },
  },
  {
    name: "list_models",
    description: "List installed model files. With `folder` (e.g. checkpoints, diffusion_models, unet, vae, loras, clip, text_encoders, clip_vision, embeddings, controlnet, upscale_models) lists that folder only. Without `folder` scans common folders and returns only non-empty ones. Use to pick valid `ckpt_name`/`unet_name`/`vae_name`/`lora_name` values when filling loader nodes.",
    inputSchema: { type: "object", properties: { folder: { type: "string" } } },
  },
  {
    name: "get_default_graph",
    description: "Return ComfyUI's default workflow graph in API JSON format. Useful as a starting template for constructing a valid `prompt` object.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "submit_workflow",
    description: "Submit a workflow graph (API JSON) to the execution queue. `prompt` maps numeric node ids to {class_type, inputs}. An input that receives another node's output must be a 2-element array [source_node_id, output_index]. Use list_nodes + get_node_info + list_models first to build a valid graph. Returns {prompt_id, client_id, number, node_errors}.",
    inputSchema: {
      type: "object",
      properties: { prompt: { type: "object", description: "API-format workflow graph: {nodeId: {class_type, inputs}}" } },
      required: ["prompt"],
    },
  },
  {
    name: "get_status",
    description: "Check the state of a submitted job by prompt_id: 'queued', 'running', 'success', 'error', or 'unknown'. On completion also returns the list of produced output files (node, kind, filename, subfolder, type) and the status object (which contains error details on failure).",
    inputSchema: { type: "object", properties: { prompt_id: { type: "string" } }, required: ["prompt_id"] },
  },
  {
    name: "run_workflow",
    description: "Submit a workflow graph (same API JSON as submit_workflow) and poll until it finishes or times out, then automatically download every output (images/video/audio) to local disk. Returns final state plus an `outputs` array with local file paths. This is the one-shot convenience tool for executing a workflow end-to-end.",
    inputSchema: {
      type: "object",
      properties: {
        prompt: { type: "object", description: "API-format workflow graph: {nodeId: {class_type, inputs}}" },
        timeout: { type: "number", description: "max seconds to wait (default 300)" },
        poll: { type: "number", description: "poll interval ms (default 1500)" },
      },
      required: ["prompt"],
    },
  },
  {
    name: "get_output",
    description: "Download a single output file produced by ComfyUI to local disk and return its path. `filename` required; `subfolder`/`type` optional (type defaults to 'output'). For images the result also includes an inline image block. Use the filename/subfolder/type reported by get_status or run_workflow.",
    inputSchema: {
      type: "object",
      properties: { filename: { type: "string" }, subfolder: { type: "string" }, type: { type: "string" }, save_as: { type: "string" } },
      required: ["filename"],
    },
  },
  {
    name: "upload_image",
    description: "Upload a local image file into ComfyUI's input folder (needed for image-to-image / image-to-video workflows). `path` is an absolute local file path. Returns {name, subfolder, type} which you pass to a LoadImage node's `image` input.",
    inputSchema: {
      type: "object",
      properties: { path: { type: "string" }, name: { type: "string" }, subfolder: { type: "string" }, type: { type: "string" }, overwrite: { type: "boolean" } },
      required: ["path"],
    },
  },
  {
    name: "interrupt",
    description: "Interrupt (cancel) the currently running generation. No args.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "cancel_queue",
    description: "Cancel queued jobs. Set delete_all=true to clear the whole queue, or pass prompt_ids=[...] to remove specific jobs.",
    inputSchema: { type: "object", properties: { delete_all: { type: "boolean" }, prompt_ids: { type: "array", items: { type: "string" } } } },
  },
];

async function handle(name, a) {
  a = a || {};
  switch (name) {
    case "system_stats":
      return await api("/system_stats");

    case "list_nodes": {
      const all = await objectInfoAll();
      let keys = Object.keys(all).sort();
      if (a.filter) {
        const f = String(a.filter).toLowerCase();
        keys = keys.filter((k) => k.toLowerCase().includes(f));
      }
      return { total: keys.length, filter: a.filter || null, nodes: keys };
    }

    case "get_node_info": {
      const out = {};
      for (const n of a.nodes || []) {
        try {
          const o = await api("/object_info/" + encodeURIComponent(n));
          const def = o[n];
          if (def) out[n] = { category: def.category, output: def.output, output_name: def.output_name, input: def.input };
          else out[n] = null;
        } catch (e) {
          out[n] = { error: e.message };
        }
      }
      return out;
    }

    case "list_models": {
      if (a.folder) return { folder: a.folder, models: await api("/models/" + encodeURIComponent(a.folder)) };
      const out = {};
      for (const f of MODEL_FOLDERS) {
        try {
          const m = await api("/models/" + f);
          if (Array.isArray(m) && m.length) out[f] = m;
        } catch {}
      }
      return out;
    }

    case "get_default_graph":
      return await api("/prompt");

    case "submit_workflow": {
      const res = await api("/prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: a.prompt, client_id: CLIENT_ID }),
      });
      return { prompt_id: res.prompt_id, client_id: CLIENT_ID, number: res.number, node_errors: res.node_errors || {} };
    }

    case "get_status": {
      const id = a.prompt_id;
      const q = await api("/queue");
      if ((q.queue_running || []).some((x) => x[1] === id)) return { prompt_id: id, state: "running" };
      const pend = (q.queue_pending || []).find((x) => x[1] === id);
      if (pend) return { prompt_id: id, state: "queued", queue_position: pend[0] };
      const h = (await api("/history/" + encodeURIComponent(id)))[id];
      if (h) {
        const ss = (h.status || {}).status_str;
        return {
          prompt_id: id,
          state: ss === "success" ? "success" : ss === "error" ? "error" : ss || "done",
          completed: (h.status || {}).completed,
          status: h.status,
          outputs: collectOutputs(h.outputs),
        };
      }
      return { prompt_id: id, state: "unknown" };
    }

    case "run_workflow": {
      const timeout = a.timeout || 300;
      const poll = a.poll || 1500;
      const sub = await api("/prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: a.prompt, client_id: CLIENT_ID }),
      });
      const id = sub.prompt_id;
      const deadline = Date.now() + timeout * 1000;
      let last = null;
      while (Date.now() < deadline) {
        const q = await api("/queue");
        if ((q.queue_running || []).some((x) => x[1] === id)) { last = { state: "running" }; await sleep(poll); continue; }
        if ((q.queue_pending || []).some((x) => x[1] === id)) { last = { state: "queued" }; await sleep(poll); continue; }
        const h = (await api("/history/" + encodeURIComponent(id)))[id];
        if (h) {
          const ss = (h.status || {}).status_str;
          last = { state: ss === "success" ? "success" : ss === "error" ? "error" : ss || "done", history: h };
          break;
        }
        last = { state: "unknown" };
        await sleep(poll);
      }
      const files = [];
      if (last && last.history) {
        for (const f of collectOutputs(last.history.outputs)) {
          try { const d = await downloadFile(f); files.push({ ...f, path: d.path, bytes: d.bytes }); }
          catch (e) { files.push({ ...f, error: e.message }); }
        }
      }
      const summary = { prompt_id: id, state: last ? last.state : "timeout", outputs: files };
      if (last && last.history && last.history.status) summary.status = last.history.status;
      const content = [{ type: "text", text: JSON.stringify(summary, null, 2) }];
      const img = files.find((f) => f.path && /\.(png|jpe?g|webp|gif)$/i.test(f.path));
      if (img) {
        const ic = await imageContent(img.path);
        if (ic) content.push(ic);
      }
      return { content };
    }

    case "get_output": {
      const d = await downloadFile({ filename: a.filename, subfolder: a.subfolder, type: a.type, save_as: a.save_as });
      const content = [{ type: "text", text: JSON.stringify({ path: d.path, bytes: d.bytes }) }];
      const ic = await imageContent(d.path);
      if (ic) content.push(ic);
      return { content };
    }

    case "upload_image": {
      const buf = await readFile(a.path);
      const form = new FormData();
      form.append("image", new Blob([buf]), a.name || String(a.path).split(/[\\\/]/).pop());
      if (a.overwrite) form.append("overwrite", "true");
      if (a.subfolder) form.append("subfolder", a.subfolder);
      if (a.type) form.append("type", a.type);
      return await api("/upload/image", { method: "POST", body: form });
    }

    case "interrupt":
      await api("/interrupt", { method: "POST" });
      return { interrupted: true };

    case "cancel_queue": {
      const del = a.delete_all ? ["all"] : a.prompt_ids || [];
      await api("/queue", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ delete: del }) });
      return { cancelled: true, cleared: del };
    }

    default:
      throw new Error("Unknown tool: " + name);
  }
}

const server = new Server({ name: "comfyui", version: "0.1.0" }, { capabilities: { tools: {} } });
server.setRequestHandler(ListToolsRequestSchema, async () => ({ tools }));
server.setRequestHandler(CallToolRequestSchema, async (req) => {
  try {
    const res = await handle(req.params.name, req.params.arguments || {});
    if (res && res.content) return res;
    return { content: [{ type: "text", text: JSON.stringify(res, null, 2) }] };
  } catch (e) {
    return { isError: true, content: [{ type: "text", text: "Error: " + e.message }] };
  }
});

const transport = new StdioServerTransport();
await server.connect(transport);
console.error("[comfyui-mcp] ready -> " + BASE + " | client " + CLIENT_ID + " | outdir " + OUTDIR);
